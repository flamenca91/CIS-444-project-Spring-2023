<!DOCTYPE HTML>
<html lang="en">
<head>

  <title>The Note</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <style>
    /* styles for select elements */
    select {
        border-radius: 5px;
        border-width: 2px;
        background-color: red;
        border-color: black;
        font-weight: bold;
        font-style: italic;
        height: 28px;
        margin: 5px;
    }
    /* hover style for select elements */
    select:hover {
        color: red;
        border-color: lightblue;
        background-color: #00222A;
    }
    footer {
  background: linear-gradient(red, #00222A);
  padding: 20px;
  }

  .footer {
    position: fixed;
    bottom: 0;
    width: 100%;
    background-color: beige;
    flex-shrink: 0;
  }
  .footer-links {
    text-align: center;
    margin: 10px;
  }
  .footer-links a {
    margin: 0 10px;
    color: white;
    text-decoration: none;
  }


  /* remove text decoration for all links */
    a {
      color: white;
      padding-right: 20px;
    }

    h2 {
      color: beige;
      font-style: italic;
    }
  
    /* style for table */
    table {
			border-collapse: collapse;
			width: 100%;
            
		}
	 /* set left alignment for table cells */	
		td, th {
			text-align: left;
		}

	/* set maximum width for images */	
		img {
			max-width: 100%;
			height: auto;

		}
    /* set background color and remove margin for body element */
    body {
        background-color: white;
        margin: 0;
    }

    input[type=text] {
        width: 100%;
        padding: 12px 20px;
        border-radius: 10px;
        /* margin: 8px 0; */
        display: inline-block;
        border: 1px solid black;
        box-sizing: border-box;
    }
    /* style for search bar */    
    #searchbar {
        width: 500px;
        height: 30px;
        font-size: 20px;
        border-radius: 5px
    }
    /* style for customer buttons */
    .customerbuttons {
        color: black;
        text-decoration: underline;
        font-weight: bold
    }
    /* style for customer buttons */
    .row {
        display: block;
        text-align: center;
    }
  
    /* style for column */
   .column {
    margin: 0 10px; /* Change the value to adjust the spacing */
  }
  
    /* style for images in columns */
  .column img {
    display: block;
    margin-left: auto;
    margin-right: auto;
  }

    /* style for caption */
  .caption {
    text-align: center;
    margin-top: 10px;
  }

    /* style for body */
  body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
}

/* use box-sizing border-box for all elements */
* {
  box-sizing: border-box;
}

 /* style for row with columns */
.row > .column {
  padding: 0 8px;
}

/* clear floats after row */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* style for column */
.column {
  float: left;
  width: 25%;
}

/* The Modal (background) */
.modal {
  display: none;
  position: fixed;
  z-index: 1;
  padding-top: 100px;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  overflow: auto;
  background-color: black;
}

/* Modal Content */
.modal-content {
  position: relative;
  background-color: #fefefe;
  margin: auto;
  padding: 0;
  width: 90%;
  max-width: 1200px;
}

/* The Close Button */
.close {
  color: white;
  position: absolute;
  top: 10px;
  right: 25px;
  font-size: 35px;
  font-weight: bold;
}

/* This section styles the close button when it's hovered or in focus */
.close:hover,
.close:focus {
  color: #999;
  text-decoration: none;
  cursor: pointer;
}

/* This section hides the slides */
.mySlides {
  display: none;
  justify-content: center; /* Center the slider horizontally */
  align-items: center; /* Center the slider vertically */
}

/* This section styles the slider */
#slider {
  width: 90%; /* Set the width of the slider */
  margin: 0 auto; /* Center the slider horizontally */
  overflow: hidden;
}

/* This section styles the images inside the slider */
.slide {
  width: 100%; /* Set the width of the images to 100% of the slider */
  height: auto; /* Set the height of the images to be determined by the width to maintain aspect ratio */
  object-fit: cover; /* Ensure the images fill the slider and maintain aspect ratio */
}

/* Number text (1/3 etc) */
.numbertext {
  color: red;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* image bordering */
img {
  margin-bottom: -4px;
  border-radius: 20px;
}

/* hover over special deals section */
.hover-shadow:hover {
    filter: brightness(150%);
}

/* hover over shop by category section */
.popularImages:hover {
  opacity: 0.7;
}

/* This section styles the caption container */
.caption-container {
  text-align: center;
  background-color: black;
  padding: 2px 16px;
}
  
/* This section styles the demo */
.demo {
  opacity: 0.6;
}


/* This section styles the navigation links */
nav a {
  color: red;
  text-decoration: none;
  font-size: 14px;
  text-transform: uppercase;
  letter-spacing: 1px;
  font-weight: bold;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  font-style: italic;
  background-color: red;
  display: none;
  position: absolute;
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  white-space: nowrap;
}

.dropdown-content a:hover {
  color: beige;
  background-color: #00222A;
}

.dropdown:hover .dropdown-content {
  display: block;
}

.rotate{
        width: 300px;
        height: 200px;
        border-radius: 80%;
        background: linear-gradient(0.25turn, red, rgb(0, 0, 0), #015467);
        animation: animate 10s linear infinite;
        perspective: 800px;
    }
@keyframes animate {
    0%{
       transform: rotateY(0deg);
    }
    100%{
        transform: rotateY(360deg);
    }
}

.typewriter p {
  overflow: hidden; /* Ensures the content is not revealed until the animation */
  border-right: .15em solid red; /* The typwriter cursor */
  white-space: nowrap; /* Keeps the content on a single line */
  margin: 0 auto; /* Gives that scrolling effect as the typing happens */
  letter-spacing: .15em; /* Adjust as needed */
  animation: 
    typing 7.5s steps(30, end),
    blink-caret 1.0s step-end infinite;
  margin-top: 10px;
  margin-bottom: 10px;
}

/* The typing effect */
@keyframes typing {
  from { width: 0 }
  to { width: 80% }
}

/* The typewriter cursor effect */
@keyframes blink-caret {
  from, to { border-color: transparent }
  50% { border-color: black}
}
  </style>
</head>
<body>
  <!-- header with image link -->
  <div style="background-color: #00222A;">
    <table>
      <tr>
        <td>
          <a href="index.php"><img src="https://cdn.discordapp.com/attachments/1081053312775889007/1086413142743068802/cropped.jpg" alt="image description" width="450" height="200"></a>
        </td>
        <td style="text-align: right; color: grey">
          333 S Twin Oaks Valley Rd, San Marcos, CA 92096<br>
          <a href="tel:+18583828890"><span style="color: lightblue;">+1 (858) 382-8890</span></a>
        </td>
      </tr>
    </table>
  </div>
    
  <!-- search bar and navigation links -->
  <table style = "background-color: white">
    <tr>
        <td><input style="margin-left: 8px;" type = "text" id = "searchbar"><input type = "submit" value = "Search" style ="margin-left: 6px; height: 34px; width: 75px; border-color: black; border-radius: 5px; border-width: 1px; font-size: 20px; background-color: lightgrey"></td>
        <td>
            <span style="display: flex; justify-content: right;">
                <div class="dropdown">
                  <a href="#"><img style="width: 29%; background-color: white; " src="https://media.discordapp.net/attachments/1081053312775889007/1098800015897530368/profile.png" alt="profile" class="profileIcon"></a>
                  <div class="dropdown-content">
                    <a href="account.html">Account</a>
                    <a href="signin.php">Login</a>
                    <a href="signup.php">Sign up</a>
                  </div>
                </div>
                <div class="dropdown">
                <a href="shoppingcart.php"><img style="width: 30%; background-color: white;" src="https://media.discordapp.net/attachments/1081053312775889007/1098802071618199623/cart.png" alt="profile" class="profileIcon"></a>
              </div>
            <img src="https://cdn0.tnwcdn.com/wp-content/blogs.dir/1/files/2016/05/instagram-logo.png" alt="Instagram logo" height= "100px" width = "98px" style="height: 30px; margin-right: 50px; margin-left: -50px;"/>
            <img src="https://img.freepik.com/premium-vector/blue-social-media-logo_197792-1759.jpg?w=2000" alt="fb logo" height = "20px" width = "48px" style="height: 30px; margin-left: -10px; margin-right: 10px;">
          </span>
          </td>
      </tr>   
    </table>
    
   <!-- navigation menu with select elements -->
  <p style="background: linear-gradient(#00222A, red); text-align: left; margin: 0; line-height: 2.5">
    <select onchange="window.location.href=this.value"; style = "background: linear-gradient(grey, lightgrey)">
      <option value="">CDs/DVDs</option>
      <option value="classicalcds_dvds.php">Classical</option>
      <option value="popcds_dvds.php">Pop</option>
      <option value="rockcdsanddvds.php">Rock &amp; Metal</option>
      <option value="reggaecds_dvds.php">Reggae</option>
    </select>
    <select onchange="window.location.href=this.value;" style = "background: linear-gradient(grey, lightgrey)">
      <option value="">Records</option>
      <option value="recordplayers.php">Record Players</option>
      <option value="records.php">Vinyls</option>
    </select>
    <select onchange="window.location.href=this.value;" style = "background: linear-gradient(grey, lightgrey)">
      <option value="">Merchandise</option>
      <option value="shirtandhoodies.php">Shirts &amp; Hoodies</option>
      <option value="accessories.php">Accessories</option>
    </select>
    <select onchange="window.location.href=this.value;"  style = "background: linear-gradient(grey, lightgrey)">
      <option value="">Instruments</option>
      <option value="guitars.php">Guitars</option>
      <option value="drums.php">Drums</option>
      <option value="pianos.php">Pianos &amp; Keyboards</option>
    </select>
    <select onchange="window.location.href=this.value;"  style = "background: linear-gradient(grey, lightgrey)">
      <option value="">Specials</option>
      <option value="specials.php">NoteSpecials</option>
    </select>
    <br>
  </p>

   <!-- Add a main section with a welcome message and featured articles -->
   <!-- Add a main section with a welcome message and featured articles -->
<div style="text-align: center; background: white; padding: 10px;">
  <!-- content goes here -->
  <h2 style="color: black; margin-top: auto;">Our Philosophy</h2>
</div>
<div style="display: flex; justify-content: center; align-items: center; flex-direction: column; text-align: center;">
  <div class='rotate'><img src="philosophy.jpg" alt="Example Product 2" width="850" height="400" style="margin-bottom: 20px;"></div>
  <p style="font-size: 20px;">The Note is a center for all your music needs! Whether it’s instruments, music, or merchandise from your favorite artists, we have it!</p>
</div>

<div id="slider">
  <img class="slide" src="image1.jpg" alt="image1">
  <img class="slide" src="image2.jpg" alt="image2">
  <img class="slide" src="image3.jpg" alt="image3">
  <img class="slide" src="image4.jpg" alt="image4">
  <img class="slide" src="image5.jpg" alt="image5">
</div>
  
          <script>
            var slideIndex = 0;
            showSlides();
            
            function showSlides() {
              var i;
              var slides = document.getElementsByClassName("slide");
              for (i = 0; i < slides.length; i++) {
                slides[i].style.display = "none";
              }
              slideIndex++;
              if (slideIndex > slides.length) {slideIndex = 1}
              slides[slideIndex-1].style.display = "block";
              setTimeout(showSlides, 5000); // Change image every 10 seconds
            }
            </script>
            
            
            <div style="text-align:center; background: linear-gradient(#00222A, red);padding: 60px;margin-top: 15px;">
              <!-- content goes here -->
              <h2>Shop By Category</h2>
            </div>
            <h3 style="text-align: center; font-style: italic">Records</h3>
            <div style="text-align: center">
              <a href = "recordplayers.php"><img class="popularImages" src="recordplayer.jpg" alt="description of image" width="175" height="200" style="border-radius: 50px; margin-left: 15px; border: none;"></a>
              <a href = "records.php"><img class="popularImages" src="vinyl.jpg" alt="description of image" width="175" height="200" style="border-radius: 50px; margin-left: 15px; border: none;"></a>
            </div>
            
            <h3 style="text-align: center; font-style: italic">Merchandise</h3>
            <div style="text-align: center">
              <a href = "accessories.php"><img class="popularImages" src="merch.jpg" alt="description of image" width="175" height="200" style="border-radius: 50px; margin-left: 15px; border: 0;"></a>
              <a href = "shirtandhoodies.php#Hoodies"><img class="popularImages" src="hoodie.jpg" alt="description of image" width="175" height="200" style="border-radius: 50px; margin-left: 15px; border: 0;"></a>
              <a href = "shirtandhoodies.php#Shirts"><img class="popularImages" src="shirt.jpg" alt="description of image" width="175" height="200" style="border-radius: 50px; margin-left: 15px; border: 0;"></a>
            </div>
            
            <h3 style="text-align: center; font-style: italic">Instruments</h3>
            <div style="text-align: center">
              <a href = "guitars.php#Eguitars"><img class="popularImages" src="https://cdn.fuelrocks.com/1662629161341.jpg" alt="Why Ibanez Guitars Are The Best Electric Guitars To Buy – FuelRocks" width="175" style="border-radius: 50px; margin-left: 15px; border: 0;"></a>
              <a href = "drums.php#ADrums"><img class="popularImages" src="https://www.samash.com/media/catalog/product/p/d/pdcm215pw.jpg?quality=80&amp;bg-color=255,255,255&amp;fit=bounds&amp;height=1200&amp;width=1200&amp;canvas=1200:1200" alt="Buy PDP Concept Maple Series 5-Piece Drum Shell Pack (Pearlescent White, Lacquer) | Sam Ash Music" width="175" style="border-radius: 50px; margin-left: 15px; border: 0;"></a>
              <a href = "pianos.php#EPianos"><img class="popularImages" src="https://i5.walmartimages.com/asr/593b00d6-c75c-4d3b-9a4e-ee9ab7cbbe6e.0dfc4d8e1a184087d373a9f0a5104c55.jpeg" alt="61 Keys Electronic Keyboard Piano for Beginner, with Music Stand and Mini Microphone, Multi-function Educational Music Instrument Toy - Walmart.com" width="175" style="border-radius: 50px; margin-left: 15px; border: 0;"></a>
              <a href = "guitars.php#AGuitars"><img class="popularImages" src="https://www.samash.com/media/catalog/product/k/e/keb_mo_1.png?quality=80&amp;bg-color=255,255,255&amp;fit=bounds&amp;height=1200&amp;width=1200&amp;canvas=1200:1200" alt="Buy Gibson Keb&#39; Mo&#39; &quot;3.0&quot; 12-Fret J-" width="175" style="border-radius: 50px; margin-left: 15px; border: 0;"></a>
            </div>

          <h3 style="text-align: center; font-style: italic;">CDs &amp; DVDs</h3>
          <div style="display: flex; justify-content: center;">
            <a = href = "classicalcds_dvds.php"><img class="popularImages" src="classical.jpg" alt="Classical music" width="175" height="200" style="border-radius: 50px; margin: 0 15px;"></a>
            <a = href = "popcds_dvds.php"><img class="popularImages" src="pop.jpg" alt="Pop music" width="175" height="200" style="border-radius: 50px; margin: 0 15px;"></a>
            <a = href = "rockcdsanddvds.php"><img class="popularImages" src="rock.jpg" alt="Rock music" width="175" height="200" style="border-radius: 50px; margin: 0 15px;"></a>
            <a = href = "reggaecds_dvds.php"><img class="popularImages" src="reggae.jpg" alt="Reggae music" width="175" height="200" style="border-radius: 50px; margin: 0 15px;"></a>
          </div>
          
      
              <div style="text-align:center; background: linear-gradient(#00222A, red); padding: 60px;margin-top: 15px;">
                <h2>Our Specials</h2>
              </div>
              
              <div class="row" style="background-color: white; height: 500px; display: flex; flex-direction: row;">
                <div class="column">
                    <figure>
                        <a href="specials.php#PDrums">
                            <img src="drums.jpg" style="width:100%; height:250px" onclick="openModal();currentSlide(1)" class="hover-shadow cursor">
                        </a>
                        <figcaption>
                            <h2 style="text-align: center; color: black;">New Pearl’s drum sets</h2>
                            <p style="text-align: center;">Make your Drumming Voice heard with Pearl’s sound-sculpting array of premium percussion</p>
                        </figcaption>
                    </figure>
                </div>
                <div class="column">
                    <figure>
                        <a href="specials.php#SMerchandise">
                            <img src="accessories.jpg" style="width:100%; height:250px" onclick="openModal();currentSlide(3)" class="hover-shadow cursor">
                        </a>
                        <figcaption>
                            <h2 style="text-align: center; color: black;">Merchandise</h2>
                            <p style="text-align: center;">Get your hands on our awesome merchandise! Buy one get one half off.</p>
                        </figcaption>
                    </figure>
                </div>
                <div class="column">
                    <figure>
                      <a href="specials.php#IGuitars">
                        <img src="ibanez.jpg" style="width:100%; height:250px" onclick="openModal();currentSlide(2)" class="hover-shadow cursor">
                    </a>
                        <figcaption>
                            <h2 style="text-align:center; color: black;">Guitars</h2>
                            <p style="text-align: center;">10% off all electric guitars by Ibanez</p>
                        </figcaption>
                    </figure>
                </div>
                <div class="column">
                    <figure>
                      <a href="specials.php#SCd's">
                        <img src="cds.jpg" style="width:100%;height:250px" onclick="openModal();currentSlide(2)" class="hover-shadow cursor">
                    </a>
                        <figcaption>
                            <h2 style="text-align: center; color: black">DVD's and CD's</h2>
                            <p style="text-align: center;">Buy 5 CDs or DVDs for a total of $49</p>
                        </figcaption>
                    </figure>
                </div>
            </div>
    <!-- Footer -->
    <div class="footer">
  <footer>
    <div class="footer-links">
      <a href="#">Contact Us</a>
      <a href="faq.php">FAQ</a>
    </div>
    </footer> 
</div>     
      </body>
      </html>
