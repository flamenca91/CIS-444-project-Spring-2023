<?php
if (isset($_POST['item'])) {
    $inventory = array(
        'alliance_beethoven' => 25.00,
        'alliance_stravinsky' => 22.00,
        'alliance_maria_callas' => 45.00,
        'alliance_debussy' => 20.00,
        'mozart_symphony' => 9.99,
        'bond_live' => 30.00,
        'sarah_live' => 24.00,
        'andre_celeb' => 19.99,
        'lady_gaga' => 37.99,
        'david_bowie' => 41.99,
        'madonna_ray' => 34.00,
        'camilla' => 25.99,
        'elton_john' => 28.99,
        'mariah_carey' => 19.00,
        'billy_joel' => 9.00,
        'janet_jackson' => 14.99,
        'pink_floyd' => 29.99,
        'jimi_hndrx' => 30.99,
        'black_sabbath' => 33.00,
        'metallica' => 48.00,
        'rush_live' => 11.99,
        'steve_dt_live' => 16.00,
        'thedoors_live' => 12.00,
        'led_zeppelin' => 28.00,
        'bob_wailers' => 24.99,
        'des_aces' => 35.99,
        'greg_sf' => 18.00,
        'peter_tosh' => 46.00,
        'regg_hero' => 11.00,
        'rebel_story' => 15.00,
        'rockers' => 14.00,
        'fire_inbabylon' => 22.99,
        'gemini_gtt' => 300.00,
        'gemini_tt' => 120.00,
        'at_lp' => 240.00,
        'crosley_du' => 21.00,
        'gemini_br' => 149.00,
        'gemini_twelve' => 199.00,
        'stanton_stx' => 250.00,
        'crosley_du2' => 35.00,
        'fleetwood_mac' => 24.50,
        'van_halen' => 30.50,
        'mj_bad' => 25.50,
        'sinatra' => 40.00,
        'lauryn_hill' => 20.50,
        'miles_davis' => 35.50,
        'vr_hamilton' => 80.00,
        'johnny_cash' => 40.50,
        'bravado_t' => 16.99,
        'gc_t' => 16.50,
        'slash_t' => 23.50,
        'pink_floyd_t' => 29.50,
        'zildjian_h' => 45.50,
        'vicfirth_h' => 36.50,
        'prs_h' => 60.00,
        'zildjian_h' => 21.50,
        'gator_g' => 800.00,
        'roadrunner' => 90.99,
        'gator_gkb' => 150.00,
        'rr_avenue' => 120.50,
        'ernie_ball' => 30.33,
        'gear_one' => 15.99,
        'strobo_stomp' => 160.00,
        'fender' => 42.50,
        'yamaha_key' => 205.00,
        'pedal_unit' => 75.00,
        'proline' => 43.99,
        'ergo_lo' => 65.00,
        'yam_cc' => 820.00,
        'cordoba_5' => 85.50,
        'lucero' => 145.00,
        'ibanez_aeg' => 125.50,
        'guild_m' => 770.00,
        'martin' => 1200.00,
        'blueridge' => 810.00,
        'ilag' => 140.50,
        'strato' => 220.00,
        'prs_se' => 79.99,
        'lespaul' => 44.99,
        'squier' => 65.50,
        'drum_1' => 200.00,
        'drum_2' => 350.00,
        'drum_3' => 410.00,
        'drum_4' => 500.00,
        'electricdrum_1' => 275.00,
        'electricdrum_2' => 320.00,
        'electricdrum_3' => 470.00,
        'electricdrum_4' => 600.00,
        'piano_1' => 280.00,
        'piano_2' => 325.00,
        'piano_3' => 480.00,
        'piano_4' => 610.00,
        'keyboard_1' => 510.00,
        'keyboard_2' => 700.00,
        'keyboard_3' => 650.00,
        'keyboard_4' => 400.00,
        'pearl_1' => 540.00,
        'pearl_2' => 700.99,
        'pearl_3' => 1000.00,
        'pearl_4' => 1500.00,
        'merch_1' =>19.10,
        'merch_2' => 150.50,
        'merch_3' => 45.10,
        'merch_4' => 9.99,
        'ibanezguitar_1' => 345.00,
        'ibanezguitar_2' => 249.00,
        'ibanezguitar_3' => 530.00,
        'ibanezguitar_4' => 550.00,
        'salecd_1' => 12.00,
        'salecd_2' => 16.10,
        'salecd_3' => 8.00,
        'salecd_4' => 11.00,
        'saledvd_1' => 13.99,
        'saledvd_2' => 12.99,
        'saledvd_3' => 15.99,
        'saledvd_4' => 49.99,


    );

    $total = 0;
    foreach ($_POST['item'] as $item) {
        if (isset($inventory[$item])) {
            $total += $inventory[$item];
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart</title>
    <style>

* {
  box-sizing: border-box;
}

body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
  }

  select {
        border-radius: 5px;
        border-width: 2px;
        background-color: red;
        border-color: black;
        font-weight: bold;
        font-style: italic;
        height: 28px;
        margin: 5px;
    }

footer {
  background: linear-gradient(red, #00222A);
  padding: 20px;
}

.footer {
  position: fixed;
  bottom: 0;
  width: 100%;
}
.footer-links {
  text-align: center;
  margin: 10px;
}
.footer-links a {
  margin: 0 auto;
  color: white;
}
  a {
    color: white;
    padding-right: 20px;
    }

  b {
  color: black;
  }

table {
	border-collapse: collapse;
	width: 100%;
  }

img {
	max-width: 100%;
	height: auto;
  background-color: lightblue;
	}

td, th {
	text-align: left;
  }

  select:hover {
    color: beige;
    border-color: lightblue;
    background-color: #00222A;
    }

#searchbar {
  width: 500px;
  height: 30px;
  font-size: 20px;
  border-radius: 5px
  }

.customerbuttons {
  color: black;
  text-decoration: underline;
  font-weight: bold
  }

.row {
  display: block;
  text-align: center;
  }

.column {
  column {
  margin: 0 10px; /* Change the value to adjust the spacing */
  }
  }

.column img {
  display: block;
  margin-left: auto;
  margin-right: auto;
  }

.caption {
  text-align: center;
  margin-top: 10px;
  }

.row > .column {
  padding: 0 8px;
  }

.row:after {
  content: "";
  display: table;
  clear: both;
  }

.column {
  float: left;
  width: 25%;
  }

h3 {
  color: black;
  font-size: 30px;
  font-weight: bold;
  margin-top: auto;
}

hr {
  border: 1px solid black;
  }

h4 {
  color: black;
  font-weight: bold;
  margin-top: auto;
}

form {
    width: 80%;
    margin: 0 auto;
    text-align: left;
    align-items: center;
    border: none;
    }

.container {
  margin: 0 auto;
  /* background-image: linear-gradient(to right, grey , beige); */
  width: 80%;
  padding: 20px;
  border: none;
  border-radius: 10px;
  border-radius: 3px;
}

.row {
  display: flex;
  flex-wrap: wrap;
  margin: 0 -10px;
}

.col-25 {
  flex: 1 0 25%;
}

.col-25 {
  padding: 0 16px;
}

input[type=text] {
  width: 100%;
  padding: 12px;
  border: 1px solid black;
  border-radius: 10px;
  font-size: 16px;
  height: 40px;
}

label {
  margin-bottom: 10px;
  display: block;
}

.icon-container {
  margin-bottom: 20px;
  padding: 7px 0;
  font-size: 24px;
}

.btn {
  font-style: italic;
  font-weight: bold;
  border-radius: 10px;
  background-color: red;
  color: solid black;
  padding: 12px;
  border: 1px solid black;
  width: 50%;
  border-radius: 3px;
  cursor: pointer;
  font-size: 17px;
}

.btn:hover {
  background-image: linear-gradient(to bottom, #00657c, black);
  color: beige;
}

span.price {
  float: right;
  color: black;
}

.cart-item-details {
  display: flex;
  flex-direction: column;
}

.cart-item-details p {
  margin: 0;
}

.cart-item-details label {
  display: inline-block;
  margin-right: 10px;
}


.cart-item-details input {
  display: inline-block;
  margin-bottom: 10px;
  padding: 5px;
  border: 1px solid black;
  border-radius: 3px;
  width: 60px;
}

.remove-item {
  font-style: italic;
  font-weight: bold;
  background-image: linear-gradient(beige, red);
  color: solid black;
  border: 1px solid black;
  border-radius: 10px;
  cursor: pointer;
  width: 70px;
}

.remove-item:hover {
  background-image: linear-gradient(to bottom, #00657c, black);
  color: beige;
}

.cart-total {
  font-size: 20px;
  font-weight: bold;
  margin-top: 20px;
}

.cart-section {
    background-color: #f9f9f9;
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 5px;
    margin-top: 20px;
}

.cart-section h2 {
    font-size: 20px;
    font-weight: bold;
    margin-top: 0;
    margin-bottom: 10px;
}

.cart-section ul {
    list-style-type: none;
    padding: 0;
    margin: 0;
}

.cart-section li {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 5px;
}

.cart-section p {
    font-weight: bold;
    margin-top: 0;
}


.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  font-style: italic;
  background-color: red;
  display: none;
  position: absolute;
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  white-space: nowrap;
}

.dropdown-content a:hover {
  color: beige;
  background-color: #00222A;
}

.dropdown:hover .dropdown-content {
  display: block;
}

@media (max-width: 300px) {
  .col-25 {
    flex-basis: 100%;

  }
}
    </style>
</head>
  <!-- header with image link -->
  <div style="background-color: #00222A;">
    <table>
      <tr>
        <td>
          <a href="index.php"><img src="https://cdn.discordapp.com/attachments/1081053312775889007/1086413142743068802/cropped.jpg" alt="image description" width="450" height="200"></a>
        </td>
        <td style="text-align: right; color: grey">
          333 S Twin Oaks Valley Rd, San Marcos, CA 92096<br>
          <a href="tel:+18583828890"><span style="color: lightblue;">+1 (858) 382-8890</span></a>
        </td>
      </tr>
    </table>
  </div>
    
  <!-- search bar and navigation links -->
  <table style = "background-color: white">    
    <tr>
        <td><input style="margin-left: 8px;" type = "text" id = "searchbar"><input type = "submit" value = "Search" style ="margin-left: 6px; height: 34px; width: 75px; border-color: black; border-radius: 5px; border-width: 1px; font-size: 20px; background-color: lightgrey"></td>
        <td>
            <span style="display: flex; justify-content: right;">
                <div class="dropdown">
                  <a href="#"><img style="width: 29%; background-color: white; " src="https://media.discordapp.net/attachments/1081053312775889007/1098800015897530368/profile.png" alt="profile" class="profileIcon"></a>
                  <div class="dropdown-content">
                    <a href="account.html">Account</a>
                    <a href="signin.php">Login</a>
                    <a href="signup.php">Sign up</a>
                  </div>
                </div>
              <div class="dropdown">
                <a href="#"><img style="width: 30%; background-color: white;" src="https://media.discordapp.net/attachments/1081053312775889007/1098802071618199623/cart.png" alt="profile" class="profileIcon"></a>
                <div class="dropdown-content">
                  <a href="shoppingcart.php">Shopping Cart</a>
                </div>
              </div>
            <img src="https://cdn0.tnwcdn.com/wp-content/blogs.dir/1/files/2016/05/instagram-logo.png" alt="Instagram logo" height= "100px" width = "98px" style="height: 30px; margin-right: 50px; margin-left: -50px;"/>
            <img src="https://img.freepik.com/premium-vector/blue-social-media-logo_197792-1759.jpg?w=2000" alt="fb logo" height = "20px" width = "48px" style="height: 30px; margin-left: -10px; margin-right: 10px;">
          </span>
          </td>
      </tr>   
    </table>
    
  <!-- navigation menu with select elements -->
  <p style="background: linear-gradient(#00222A, red); text-align: left; margin: 0; line-height: 2.5">
    <select onchange="window.location.href=this.value"; style = "background: linear-gradient(grey, lightgrey)">
      <option value="">CDs/DVDs</option>
      <option value="classicalcds_dvds.php">Classical</option>
      <option value="popcds_dvds.php">Pop</option>
      <option value="rockcdsanddvds.php">Rock &amp; Metal</option>
      <option value="reggaecds_dvds.php">Reggae</option>
    </select>
    <select onchange="window.location.href=this.value;" style = "background: linear-gradient(grey, lightgrey)">
      <option value="">Records</option>
      <option value="recordplayers.php">Record Players</option>
      <option value="records.php">Vinyls</option>
    </select>
    <select onchange="window.location.href=this.value;" style = "background: linear-gradient(grey, lightgrey)">
      <option value="">Merchandise</option>
      <option value="shirtandhoodies.php">Shirts &amp; Hoodies</option>
      <option value="accessories.php">Accessories</option>
    </select>
    <select onchange="window.location.href=this.value;"  style = "background: linear-gradient(grey, lightgrey)">
      <option value="">Instruments</option>
      <option value="guitars.php">Guitars</option>
      <option value="drums.php">Drums</option>
      <option value="pianos.php">Pianos &amp; Keyboards</option>
    </select>
    <select onchange="window.location.href=this.value;"  style = "background: linear-gradient(grey, lightgrey)">
      <option value="">Specials</option>
      <option value="specials.php">NoteSpecials</option>
    </select>
    <br>
  </p>
	
  <body>
    <div class="cart-section">
       <?php
    if (isset($_POST['item'])) {
        echo '<h2>Selected Items:</h2>';
        echo '<ul>';
        foreach ($_POST['item'] as $item) {
            echo '<li>' . $item . '</li>';
        }
        echo '</ul>';

        echo '<h2>Total Price:</h2>';
        echo '<p>$' . number_format($total, 2) . '</p>';
    }
    ?> 
    </div>
    <a style= "text-align: center; margin-left: 25%;" href="checkout.php">
    <input type="submit" value="Continue to checkout" class="btn">
    <!-- Footer -->
  <div class="footer">
  <footer>
    <div class="footer-links">
      <a href="#">Contact Us</a>
      <a href="faq.php">FAQ</a>
    </div>
    </footer> 
</div>     
</body>
</html>
