<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Account</title>
  <style>
    * {
        box-sizing: border-box;
        }

        body {
        font-family: Arial, Helvetica, sans-serif;
        margin: 0;
        }

        select {
        border-radius: 5px;
        border-width: 2px;
        background-color: red;
        border-color: black;
        font-weight: bold;
        font-style: italic;
        height: 28px;
        margin: 5px;
    }
        footer {
        background: linear-gradient(red, #00222A);
        padding: 20px;
      }

            .footer {
        position: fixed;
        bottom: 0;
        width: 100%;
        background-color: beige;
        }
        .footer-links {
        text-align: center;
        margin: 10px;
        }
        .footer-links a {
        margin: 0 10px;
        color: white;
        text-decoration: none;
        }

      /* remove text decoration for all links */
      a {
        color: white;
        padding-right: 20px;
      }
        table {
			border-collapse: collapse;
			width: 100%;
            
		}

        img {
			max-width: 100%;
			height: auto;
      background-color: lightblue;
		}

        td, th {
			text-align: left;
		}
    select:hover {
        color: beige;
        border-color: lightblue;
        background-color: #00222A;
    }

        input[type=text]{
            width: 100%;
            padding: 12px 20px;
            border-radius: 10px;
            display: inline-block;
            border: 1px solid black;
            box-sizing: border-box;
        }

        #searchbar {
        width: 500px;
        height: 30px;
        font-size: 20px;
        border-radius: 5px
        }

        .customerbuttons {
        color: black;
        text-decoration: underline;
        font-weight: bold
        }

        .row {
        display: block;
        text-align: center;
        }

        .column {
        column {
        margin: 0 10px;
        }
        }

        .column img {
        display: block;
        margin-left: auto;
        margin-right: auto;
        }

        .caption {
        text-align: center;
        margin-top: 10px;
        }

        .row > .column {
           padding: 0 8px;
        }

        .row:after {
        content: "";
        display: table;
        clear: both;
        }

        .column {
            float: left;
            width: 25%;
        }

        label {
            color: black;
            font-size: 18px;
            font-style: normal;
            margin: 0 auto;
            padding: 10px;
            text-align: left;
        }
        

/* The Modal (background) */
.modal {
  display: none;
  position: fixed;
  z-index: 1;
  padding-top: 100px;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  overflow: auto;
  background-color: black;
}

/* Modal Content */
.modal-content {
  position: relative;
  background-color: #fefefe;
  margin: auto;
  padding: 0;
  width: 90%;
  max-width: 1200px;
}

button {
  font-style: italic;
  font-weight: bold;
  background-color: red;
  border-radius: 10px;
  color: solid black;
  border: 1px solid black;
  cursor: pointer;
  width: 15%;
  margin: auto;
  height: 40px;
  font-size: 14px;
  }
  button:hover {
  background-image: linear-gradient(to bottom, #00657c, black);
  color: beige;
  }

  .dropdown {
  position: relative;
  display: inline-block;
  }
  
  .dropdown-content {
  font-style: italic;
  background-color: red;
  display: none;
  position: absolute;
  z-index: 1;
  }

  .dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  white-space: nowrap;
  }

  .dropdown-content a:hover {
  color: beige;
  background-color: #00222A;
  }

  .dropdown:hover .dropdown-content {
  display: block;
  }

.demo {
  opacity: 0.6;
}
</style>
</head>
<body>
<?php

require_once("config.php");

if(isset($_GET['noteID']))
  $FlyerID = $_GET['noteID'];
  
  
  //get existing user info from the database, to be shown in the form
$TableName = "thenote_users";
$sql = "SELECT * FROM $TableName WHERE noteID = '$NoteID' ";
$result = $pdo->query($sql);
if($row = $result->fetch()){
    $Last=$row["last"];
    $First=$row["first"];
    $Phone=$row["phone"];
    $Address=$row["address"];
    $State=$row["state"];
    $City=$row["city"];
    $Zip=$row["zip"];
}
else{
    $Last="";
    $First="";
    $Phone="";
    $Address="";
    $State="";
    $City="";
    $Zip="";
}

// closes connection and frees the resources used by the PDO object
$pdo = null;
?>
<!-- header with image link -->
<div style="background-color: #00222A;">
    <table>
      <tr>
        <td>
          <a href="index.php"><img src="https://cdn.discordapp.com/attachments/1081053312775889007/1086413142743068802/cropped.jpg" alt="image description" width="450" height="200"></a>
        </td>
        <td style="text-align: right; color: grey">
          333 S Twin Oaks Valley Rd, San Marcos, CA 92096<br>
          <a href="tel:+18583828890"><span style="color: lightblue;">+1 (858) 382-8890</span></a>
        </td>
      </tr>
    </table>
  </div>
    
  <!-- search bar and navigation links -->
  <table style = "background-color: white">    
    <tr>
        <td><input style="margin-left: 8px;" type = "text" id = "searchbar"><input type = "submit" value = "Search" style ="margin-left: 6px; height: 34px; width: 75px; border-color: black; border-radius: 5px; border-width: 1px; font-size: 20px; background-color: lightgrey"></td>
        <td>
            <span style="display: flex; justify-content: right;">
                <div class="dropdown">
                  <a href="#"><img style="width: 29%; background-color: white; " src="https://media.discordapp.net/attachments/1081053312775889007/1098800015897530368/profile.png" alt="profile" class="profileIcon"></a>
                  <div class="dropdown-content">
                    <a href="account.html">Account</a>
                    <a href="signin.php">Login</a>
                    <a href="signup.php">Sign up</a>
                  </div>
                </div>
              <div class="dropdown">
                <a href="shoppingcart.php"><img style="width: 30%; background-color: white;" src="https://media.discordapp.net/attachments/1081053312775889007/1098802071618199623/cart.png" alt="profile" class="profileIcon"></a>
              </div>
            <img src="https://cdn0.tnwcdn.com/wp-content/blogs.dir/1/files/2016/05/instagram-logo.png" alt="Instagram logo" height= "100px" width = "98px" style="height: 30px; margin-right: 50px; margin-left: -50px;"/>
            <img src="https://img.freepik.com/premium-vector/blue-social-media-logo_197792-1759.jpg?w=2000" alt="fb logo" height = "20px" width = "48px" style="height: 30px; margin-left: -10px; margin-right: 10px;">
          </span>
          </td>
      </tr>   
    </table>
    
   <!-- navigation menu with select elements -->
  <p style="background: linear-gradient(#00222A, red); text-align: left; margin: 0; line-height: 2.5">
    <select onchange="window.location.href=this.value"; style = "background: linear-gradient(grey, lightgrey)">
      <option value="">CDs/DVDs</option>
      <option value="classicalcds_dvds.php">Classical</option>
      <option value="popcds_dvds.php">Pop</option>
      <option value="rockcdsanddvds.php">Rock &amp; Metal</option>
      <option value="reggaecds_dvds.php">Reggae</option>
    </select>
    <select onchange="window.location.href=this.value;" style = "background: linear-gradient(grey, lightgrey)">
      <option value="">Records</option>
      <option value="recordplayers.php">Record Players</option>
      <option value="records.php">Vinyls</option>
    </select>
    <select onchange="window.location.href=this.value;" style = "background: linear-gradient(grey, lightgrey)">
      <option value="">Merchandise</option>
      <option value="shirtandhoodies.php">Shirts &amp; Hoodies</option>
      <option value="accessories.php">Accessories</option>
    </select>
    <select onchange="window.location.href=this.value;"  style = "background: linear-gradient(grey, lightgrey)">
      <option value="">Instruments</option>
      <option value="guitars.php">Guitars</option>
      <option value="drums.php">Drums</option>
      <option value="pianos.php">Pianos &amp; Keyboards</option>
    </select>
    <select onchange="window.location.href=this.value;"  style = "background: linear-gradient(grey, lightgrey)">
      <option value="">Specials</option>
      <option value="specials.php">NoteSpecials</option>
    </select>
    <br>
  </p>


<form action ="account_test.php" method="get">
    <table border="1">
        <tr>
            <td align="left" valign="top">
                <p>First Name <input type="text" name="first_name" value="<?=$First?>" size="36"/></p>
                <p>Last Name <input type="text" name="last_name" value="<?=$Last?>" size="36"/></p>
                <p>Phone <input type="text" name="phone" value="<?=$Phone?>" size="36"/></p>
                <p><input type="hidden" name = "flyerID" value = "<?=$FlyerID?>"/></p>
            </td>
            <td align="left" valign="top">
                <p>Address <input type="text" name="address" value="<?=$Address?>" size="40"/></p>
                <p>City <input type="text" name="city" value="<?=$City?>" size="10"/></p>
                <p>State <input type="text" name="state" value="<?=$State?>" size="2"/></p>
                <p>Zip <input type="text" name="zip" value="<?=$Zip?>" size="10" maxlength="10"/></p>
            </td>
        </tr></table>

        <p><input type="submit" value="Submit"/></p>

        <div class="footer">
  <footer>
    <div class="footer-links">
      <a href="#">Contact Us</a>
      <a href="faq.php">FAQ</a>
    </div>
    </footer> 
</div>
</form>
</body>
</html>
   